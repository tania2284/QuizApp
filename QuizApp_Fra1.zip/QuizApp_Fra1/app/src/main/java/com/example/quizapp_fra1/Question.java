package com.example.quizapp_fra1;

public class Question {
    int question;
    Boolean answer;
    int color;

    public Question(int question, Boolean answer, int color) {
        this.question = question;
        this.answer = answer;
        this.color = color;
    }

    public int getQuestion() {
        return question;
    }

    public void setQuestion(int question) {
        this.question = question;
    }

    public Boolean getAnswer() {
        return answer;
    }

    public void setAnswer(Boolean answer) {
        this.answer = answer;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }
}
