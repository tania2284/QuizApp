package com.example.quizapp_fra1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private FrameLayout framelayout;
    private Menu menu;
    private ProgressBar progressBar;
    Button buttonTrue;
    Button buttonFalse;
    int index = 0;
    QuestionBank qbank;
    int correctAns = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        framelayout = findViewById(R.id.framelayout);

        buttonFalse = findViewById(R.id.buttonFalse);
        buttonTrue = findViewById(R.id.buttonTrue);
        progressBar = findViewById(R.id.progressBar);
        qbank = new QuestionBank();
        if (savedInstanceState != null) {
            index = savedInstanceState.getInt("keyindex");

            updatefragment(qbank.queList.get(index).getQuestion(), qbank.colorList.get(index));

        } else {

            updatefragment(qbank.queList.get(index).getQuestion(), qbank.colorList.get(index));

        }
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Quiz");
    }

    private void updatefragment(int question, int color) {
        FragmentManager manager = getSupportFragmentManager();
        manager.findFragmentById(R.id.framelayout);
        FragmentQuestion myfragment = FragmentQuestion.newInstance(question, color);
        manager.beginTransaction().replace(R.id.framelayout, myfragment).commit();
        //myfragment.getView().setBackgroundColor(color);
        framelayout.setBackgroundColor(color);

    }

    protected void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt("keyindex", index);

    }

    public void onClick(View view) {
     progressBar.setProgress(index * 10);
        if (view == buttonTrue) {



            if (qbank.queList.get(index).getAnswer() == true) {
                correctAns++;


                Toast.makeText(this, "Correct", Toast.LENGTH_SHORT).show();
            }
            updatefragment(qbank.queList.get(index).getQuestion(), qbank.colorList.get(index));
            index++;

//           // else {
//
//                Toast.makeText(this, "Incorrect", Toast.LENGTH_SHORT).show();
//            }
        }
      //  if {
            index++;

            if (qbank.queList.get(index).getAnswer() == false) {
                correctAns++;
                Toast.makeText(this, "Correct", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Incorrect", Toast.LENGTH_SHORT).show();
            }
        updatefragment(qbank.queList.get(index).getQuestion(), qbank.colorList.get(index));

        }
    }


