package com.example.quizapp_fra1;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class QuestionBank {
    ArrayList<Question> queList = new ArrayList<>();
    ArrayList<Integer> colorList = new ArrayList<Integer>();

    public QuestionBank() {
        colorList.add(R.color.purple_200);
        colorList.add(R.color.teal_200);
        colorList.add(R.color.purple_700);
        colorList.add(R.color.teal_700);
        colorList.add(R.color.black);
        Collections.shuffle(colorList);

        Question que1 = new Question(R.string.Q1, true, colorList.get(0));
        Question que2 = new Question(R.string.Q2, true, colorList.get(1));
        Question que3 = new Question(R.string.Q3, true, colorList.get(2));
        Question que4 = new Question(R.string.Q4, true, colorList.get(3));
        Question que5 = new Question(R.string.Q5, true, colorList.get(4));

        queList.add(que1);
        queList.add(que2);
        queList.add(que3);
        queList.add(que4);
        queList.add(que5);

        Collections.shuffle(queList);

    }
}
